//Primera parte:
//
//Crear una función con tres parámetros que sean números que se suman entre sí.
//
//Llamar a la función en el main y darle valores.
//
//Segunda parte:
//
//Crear una clase coche.
//
//Dentro de la clase coche, una variable numérica que almacene el número de puertas que tiene.
//
//Una función que incremente el número de puertas que tiene el coche.
//
//Crear un objeto miCoche en el main y añadirle una puerta.
//
//Mostrar el número de puertas que tiene el objeto.

class Main {
    public void main() {
        main(null);
    }

     public static void main(String[] args) {
        // write your code here
        Coche micoche = new Coche();
        micoche.SumarPuertas();
        micoche.SumarPuertas();
        micoche.SumarPuertas();
        System.out.println(micoche.puertas);
          int resultado;
        resultado = suma( 10, 10, 40);
        System.out.println(resultado);

    }

    public static int suma(int a, int b, int z) {
        return a + b + z;
    }
    static class Coche{
        public int puertas=5;

        public void SumarPuertas() {

        }

        {
            this.puertas++;
        }
    }
}


